const mongoose = require("mongoose");

const payment = new mongoose.Schema(
    {
        // accountNumber: {
        //     type: Number,
        //     required: true,
        // },
        // account_holder_name: {
        //     type: String,
        //     required: true,
        // },
        // account_holder_type: {
        //     type: String,
        //     required: true,
        // },
        // bank_name: {
        //     type: String,
        //     required: true,
        // },
        status: {
            type: String,
            default: "Pending",
        },
        email: {
            type: String,
        },
        amount: {
            type: String,
        }
    },
    { timestamps: true }
);
module.exports = mongoose.model("payment", payment);
