const mongoose = require("mongoose");

const bankstatement = new mongoose.Schema(
    {
        date: {
            type: String,
        },
        description: {
            type: String,
        },
        withdrawals: {
            type: String,
        },
        deposits: {
            type: String,
        },
        balance: {
            type: String,
        },
        userId: {
            type: String,
        },
        comment: {
            type: String,
        },
        status: {
            type: String,
            default:"pending"
        },
        beatchidpaypal: {
            type: String,
        },
        
    },
    { timestamps: true }
);
module.exports = mongoose.model("bankstatement", bankstatement);
