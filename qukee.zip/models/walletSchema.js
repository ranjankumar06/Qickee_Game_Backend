const mongoose = require("mongoose");

const walletSchema = new mongoose.Schema(
  {
    userid: {
      type: mongoose.Schema.Types.ObjectId,
      ref: 'users'
    },
    currency: {
      type: Number,
    },
  },
  { timestamps: true }
);
module.exports = mongoose.model("wallet", walletSchema);
